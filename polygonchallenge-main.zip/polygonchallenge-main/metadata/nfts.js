const nfts = [
  {
    name: "0",
    description: "winnie the pooh in train",
    image: "Qmedq8eBALtGSds73U4B5rmwC82TdDUQ4QfzbXrJCG2kFV",
  },
  {
    name: "1",
    description: "winnie the pooh in train",
    image: "QmfLeMBVqkhia1JXHbXFGLA7uhYb8qSZQNakpiNB9NdpqL",
  }, //change
  {
    name: "2",
    description: "winnie the pooh in train",
    image: "QmdVjmZktibqBQQps6vnHs7PsLSRDbcEtXw6nF9e32AX45",
  },
  {
    name: "3",
    description: "winnie the pooh in train",
    image: "Qmf8BFjWJ6sXwwCLFWYeGbPvJYk49Hid8jo5grhMvXT3gi",
  },
  {
    name: "4",
    description: "winnie the pooh in train",
    image: "QmQvpYx23E5jyB3Vti6GHEXty47cgSvUJc8HGqWs4Nu1i6",
  },
];

module.exports = nfts;
